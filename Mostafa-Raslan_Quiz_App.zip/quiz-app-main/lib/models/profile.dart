class Profile {
  static String name = '';
  static int score = 0;
}
