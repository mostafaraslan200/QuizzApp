# quiz_app

A quiz app with flutter.

# App tour
![](https://github.com/Ziad-Hegazy/quiz-app/blob/main/appTour.gif)
